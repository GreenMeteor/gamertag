<?php

use yii\helpers\Url;
use yii\helpers\Html;
use yii\widgets\DetailView;
use humhub\modules\user\models\User;
use humhub\modules\ui\icon\widgets\Icon;
use humhub\modules\gamertag\models\GamerTag;

/** @var User $user */
/** @var GamerTag[] $tags */
/** @var bool $canEdit */

$this->title = Yii::t('GamertagModule.base', 'Gaming Profiles');

$this->registerJsFile('https://kit.fontawesome.com/066a7f316b.js', [
    'integrity' => 'sha384-LyufUOLOLV9L7AePtM1U3XXqUt2y7A3cbKeGz9KDA6+V9N8ABz5I4R1JJa8jK/oE',
    'crossorigin' => 'anonymous'
]);

?>

<div class="panel panel-default">
    <div class="panel-heading">
        <?= Yii::t('GamertagModule.base', '<strong>Gaming</strong> Profiles'); ?>
    </div>
    <div class="panel-body">
        <?php if ($canEdit): ?>
            <?= Html::a(
                '<i class="fa fa-plus"></i> ' . Yii::t('GamertagModule.base', 'Add Gaming Profile'),
                [$user->createUrl('/gamertag/profile/create')],
                [
                    'class' => 'btn btn-primary btn-sm pull-right',
                    'data-toggle' => 'modal',
                    'data-target' => '#globalModal'
                ]
            ); ?>
        <?php endif; ?>
    </div>

    <div class="panel-body">
        <?php if (empty($tags)): ?>
            <div class="alert alert-info text-center">
                <strong><?= Yii::t('GamertagModule.base', 'No gaming profiles added yet.'); ?></strong>
            </div>
        <?php else: ?>
            <?php foreach ($tags as $tag): ?>
                <?php $platformData = $tag->getPlatformData(); ?>
                <div class="gaming-profile-container" data-platform="<?= Html::encode(strtolower($platformData['label'] ?? '')); ?>">
                    <div class="platform-header" style="background-color: <?= $platformData['color']; ?>;">
                        <div class="platform-icon">
                            <?= Icon::get($platformData['icon']); ?>
                        </div>
                        <span class="platform-name"><?= Html::encode($platformData['label']); ?></span>
                        
                        <?php if ($canEdit): ?>
                            <div class="platform-actions">
                                <?= Html::a('<i class="fa fa-pencil"></i>', 
                                    [$user->createUrl('/gamertag/profile/update', ['id' => $tag->id])], 
                                    ['class' => 'btn btn-xs edit-btn', 'data-toggle' => 'modal', 'data-target' => '#globalModal']
                                ); ?>
                                <?= Html::a('<i class="fa fa-trash"></i>', 
                                    [$user->createUrl('/gamertag/profile/delete', ['id' => $tag->id])], 
                                    [
                                        'class' => 'btn btn-xs delete-btn',
                                        'data-method' => 'post',
                                        'data-confirm' => Yii::t('GamertagModule.base', 'Are you sure?')
                                    ]
                                ); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <?= DetailView::widget([
                        'model' => $tag,
                        'options' => [
                            'class' => 'table table-bordered detail-view gaming-detail-view',
                        ],
                        'attributes' => [
                            [
                                'label' => Yii::t('GamertagModule.base', 'Gamertag'),
                                'value' => $tag->gamertag,
                                'contentOptions' => ['class' => 'gamertag-value'],
                            ],
                            [
                                'label' => Yii::t('GamertagModule.base', 'Visibility'),
                                'value' => GamerTag::getVisibilityOptions()[$tag->visibility],
                                'contentOptions' => ['class' => 'visibility-value'],
                            ],
                            [
                                'label' => Yii::t('GamertagModule.base', 'Created'),
                                'value' => Yii::$app->formatter->asDatetime($tag->created_at),
                                'visible' => !empty($tag->created_at),
                            ],
                            [
                                'label' => Yii::t('GamertagModule.base', 'Last Updated'),
                                'value' => Yii::$app->formatter->asDatetime($tag->updated_at),
                                'visible' => !empty($tag->updated_at),
                            ],
                        ],
                    ]); ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<style>
/* Base container */
.gaming-profile-container {
    background: #ffffff;
    border-radius: 8px;
    border: 1px solid #e0e0e0;
    overflow: hidden;
    margin-bottom: 25px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.gaming-profile-container:hover {
    border-color: #d0d0d0;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* Header with platform information */
.platform-header {
    display: flex;
    align-items: center;
    padding: 15px;
    color: white;
    font-weight: 700;
    position: relative;
}

/* Platform Icon */
.platform-icon {
    font-size: 22px;
    margin-right: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 36px;
    height: 36px;
    position: relative;
    z-index: 2;
}

/* Platform Name */
.platform-name {
    letter-spacing: 0.8px;
    text-transform: uppercase;
    font-size: 15px;
    font-weight: 800;
    text-shadow: 1px 1px 1px rgba(0,0,0,0.3);
    flex-grow: 1;
}

/* Action buttons */
.platform-actions {
    display: flex;
    gap: 10px;
}

.edit-btn, .delete-btn {
    padding: 4px 8px;
    border-radius: 4px;
    display: inline-flex;
    align-items: center;
    font-weight: 600;
    border: 1px solid;
}

.edit-btn {
    background: rgba(255, 255, 255, 0.3);
    color: #ffffff !important;
    border-color: rgba(255, 255, 255, 0.4);
}

.edit-btn:hover {
    background: rgba(255, 255, 255, 0.4);
    border-color: rgba(255, 255, 255, 0.5);
}

.delete-btn {
    background: rgba(255, 255, 255, 0.3);
    color: #ffffff !important;
    border-color: rgba(255, 255, 255, 0.4);
}

.delete-btn:hover {
    background: rgba(255, 255, 255, 0.4);
    border-color: rgba(255, 255, 255, 0.5);
}

/* DetailView styling */
.gaming-detail-view {
    margin-bottom: 0;
    background: transparent;
}

.gaming-detail-view th {
    width: 25%;
    background-color: #f5f5f5 !important;
    color: #555555;
    border-color: #e0e0e0 !important;
    font-weight: 600;
    padding: 12px 15px;
}

.gaming-detail-view td {
    background-color: #ffffff !important;
    color: #333333;
    border-color: #e0e0e0 !important;
    padding: 12px 15px;
}

.gaming-detail-view .gamertag-value {
    font-family: 'Consolas', 'Monaco', monospace;
    font-size: 16px;
    color: #0070d1;
    font-weight: 500;
    letter-spacing: 0.5px;
}

.gaming-detail-view .visibility-value {
    color: #666666;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    font-size: 12px;
}

/* Platform-specific styling */
[data-platform="playstation"] .platform-header { background-color: #0070d1; }
[data-platform="xbox"] .platform-header { background-color: #107C10; }
[data-platform="nintendo"] .platform-header { background-color: #e60012; }
[data-platform="steam"] .platform-header { background-color: #171a21; }
[data-platform="epicgames"] .platform-header { background-color: #2a2a2a; }
[data-platform="battlenet"] .platform-header { background-color: #00aeff; }
[data-platform="origin"] .platform-header { background-color: #f56c2d; }
[data-platform="ubisoft"] .platform-header { background-color: #0b8fff; }
[data-platform="riot"] .platform-header { background-color: #d13639; }

/* Responsive adjustments */
@media (max-width: 767px) {
    .platform-header {
        flex-wrap: wrap;
    }
    
    .platform-actions {
        margin-top: 10px;
        width: 100%;
        justify-content: flex-end;
    }
    
    .gaming-detail-view th {
        width: 35%;
    }
}
</style>